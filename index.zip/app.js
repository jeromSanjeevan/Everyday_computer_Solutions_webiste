
// const hamburger = document.querySelector(
//   ".header .nav-bar .nav-list .hamburger"
// );
// const mobile_menu = document.querySelector(".header .nav-bar .nav-list ul");
// const menu_item = document.querySelectorAll(
//   ".header .nav-bar .nav-list ul li a"
// );
// const header = document.querySelector(".navbar.navbar-expand-md.navbar-dark.bg-dark");

// hamburger.addEventListener("click", () => {
//   hamburger.classList.toggle("active");
//   mobile_menu.classList.toggle("active");
// });

// document.addEventListener("scroll", () => {
//   var scroll_position = window.scrollY;
//   if (scroll_position > 250) {
//     header.style.backgroundColor = "#29323c";
//   } else {
//     header.style.backgroundColor = "transparent";
//   }
// });

// menu_item.forEach((item) => {
//   item.addEventListener("click", () => {
//     hamburger.classList.toggle("active");
//     mobile_menu.classList.toggle("active");
//   });
// });

//

//

// Slider Setion.............

// let slideIndex = 0;
// showSlides();

// function showSlides() {
//   let i;
//   let slides = document.getElementsByClassName("mySlides");
//   let dots = document.getElementsByClassName("dot");
//   for (i = 0; i < slides.length; i++) {
//     slides[i].style.display = "none";
//   }
//   slideIndex++;
//   if (slideIndex > slides.length) {slideIndex = 1}
//   for (i = 0; i < dots.length; i++) {
//     dots[i].className = dots[i].className.replace(" active", "");
//   }
//   slides[slideIndex-1].style.display = "block";
//   dots[slideIndex-1].className += " active";
//   setTimeout(showSlides, 2000); // Change image every 2 seconds
// }

// var img = document.getElementById('slider-img');

// var slides=['./img/slide_6.jpg','./img/slide_2.jpg', './img/slide_3.jpg','./img/slide_4.jpg'];

// var Start=0;

// function slider(){
//     if(Start<slides.length){
//         Start=Start+1;
//     }
//     else{
//         Start=1;
//     }
//     console.log(img);
//     img.innerHTML = "<img src="+slides[Start-1]+">";

// }
// setInterval(slider,7000);

// $("#slideshow > div:gt(0)").hide();

// setInterval(function () {
//   $("#slideshow > div:first")
//     .fadeOut(1000)
//     .next()
//     .fadeIn(1000)
//     .end()
//     .appendTo("#slideshow");
// }, 5000);


